#include <unistd.h>
#include <stdio.h>
#include <string.h>
#include <stdlib.h>

void error_y_exit(char *msg,int exit_status) {
	perror(msg);
	exit(exit_status);
}

int main(int argc,char *argv[]) {
	char buffer[80];
	
	if (argc == 1) error_y_exit("Este programa requiere un argumento.", 1);
	int pid;
	pid = fork();
	
	if (pid == -1) error_y_exit("No se ha podid crear un proceso hijo.", 1);
	
	sprintf(buffer,"Soy el proceso %d\n", getpid());
	write(1, buffer, strlen(buffer));
	if (pid == 0) {
		sprintf(buffer,"El argumento es %s\n", argv[1]);
		write(1, buffer, strlen(buffer));
	}
	
	while (1);
	
	return 0;
}
