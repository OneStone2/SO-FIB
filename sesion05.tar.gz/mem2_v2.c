#include <unistd.h>
#include <stdio.h>
#include <signal.h>
#include <stdlib.h>
#include <string.h>

#define REGION_SIZE		4096

int *p;

void error_y_exit(char* msg, int exit_status) {
	perror(msg);
	exit(exit_status);		
}

void seg_fault(int s) {
	char buff[128];		
	sprintf( buff, "\tProgram code -- p address: %p, p value: %p, heap end: %p\n",
		      &p, p, sbrk(0));
	write(1, buff, strlen(buff));
	exit(1);	      
	
}



int main(int argc, char *argv[]) {
	int i = 0;
	char buff[256];					
	
	struct sigaction sa;
	sa.sa_handler = &seg_fault;
	sa.sa_flags = SA_RESTART;
	sigfillset(&sa.sa_mask);
	if (sigaction(SIGSEGV, &sa, NULL) < 0) error_y_exit("sigaction", 1);
	
	sprintf(buff, "Addresses:\n");
	write(1, buff, strlen(buff));	
	sprintf(buff, "\tp: %p\n", &p);
	write(1, buff, strlen(buff));	

	p = malloc(sizeof(int));
	
	if (p == NULL) {
		sprintf(buff, "ERROR en el malloc\n");
		write(2,buff,strlen(buff));
	}

	while (1) {
		*p = i;
		sprintf( buff, "\tProgram code -- p address: %p, p value: %p, *p: %d\n",
		      &p, p, *p);
		write(1, buff, strlen(buff));	
		p++;
		i++;
	}

}
