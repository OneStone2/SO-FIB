#include <stdlib.h>
#include <stdio.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <string.h>


void error_y_exit(char* msg, int error_status) {
	perror(msg);
	exit(error_status);
}

int main() {
	char buf[256];
	int fp = open("file", O_RDWR);
	if (fp == -1) error_y_exit("open", 1);
	int x = lseek(fp, 0, SEEK_END), y = 0;
	
	while (y < x) {
		lseek(fp, y, SEEK_SET);
		read(fp, buf, sizeof(char));
		lseek(fp, 0, SEEK_END);
		write(fp, buf, sizeof(char));
		++y;
	}
}
