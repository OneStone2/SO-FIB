#include <stdlib.h>
#include <stdio.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <string.h>


void error_y_exit(char* msg, int error_status) {
	perror(msg);
	exit(error_status);
}

void usage() {
	write(1, "insertarx2 [file] [pos]\n", 27);
	write(1, "Inserta una X en la posicion pos del fichero file. pos tiene que ser 0 o una posicion del fichero.\n", 50);
	exit(0);
}

int main(int argc, char *argv[]) {
	if (argc <= 2) usage();
	char buf[256];
	int pos = atoi(argv[2]), cur;
	
	
	int fp = open(argv[1], O_RDWR);
	if (fp == -1) error_y_exit("open", 1);
	
	
	lseek(fp, 0, SEEK_END);
	
	while ((cur = lseek(fp, -sizeof(char), SEEK_CUR)) >= 0) {
		if (cur >= pos) {
			read(fp, buf, sizeof(char));
			write(fp, buf, sizeof(char));
			lseek(fp, -2*sizeof(char), SEEK_CUR);
			if (cur == pos) {
				write(fp, "X", sizeof(char));
				lseek(fp, -sizeof(char), SEEK_CUR);
			}
		}	
	}
}
