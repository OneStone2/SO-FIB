#include <stdlib.h>
#include <stdio.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <string.h>


void error_y_exit(char* msg, int error_status) {
	perror(msg);
	exit(error_status);
}

void usage() {
	write(1, "invirtiendo_fichero [file]\n", 27);
	write(1, "Invierte el contenido del fichero file y lo escribe en el fichero file.inv\n", 75);
	exit(0);
}

int main(int argc, char *argv[]) {
	if (argc == 1) usage();
	char buf[256];
	
	int fpr = open(argv[1], O_RDONLY);
	if (fpr == -1) error_y_exit("open", 1);
	
	sprintf(buf, "%s.inv", argv[1]);
	int fpw = creat(buf, O_CREAT|O_TRUNC|0600);
	if (fpw == -1) error_y_exit("creat", 1);
	
	lseek(fpr, 0, SEEK_END);
	lseek(fpw, 0, SEEK_SET);
	
	while (lseek(fpr, -sizeof(char), SEEK_CUR) >= 0) {
		write(1, "lol", 3);
		read(fpr, buf, sizeof(char));
		write(fpw, buf, sizeof(char));
		lseek(fpr, -sizeof(char), SEEK_CUR);
	}
}
