#include <unistd.h>
#include <stdio.h>
#include <signal.h>
#include <stdlib.h>
#include <errno.h>

void error_y_exit(char *msg,int exit_status) {
    perror(msg);
    exit(exit_status);
}


void trata_alarma(int s) {
	if (s == SIGINT) {
		write(1, "SIGINT recibido.\n", 17);
	}

}

int main(){
	
	struct sigaction sa;
    sigset_t mask;
    
    sa.sa_handler = &trata_alarma;
	sa.sa_flags = SA_RESTART;
	sigfillset(&sa.sa_mask);
	if (sigaction(SIGINT, &sa, NULL) < 0) error_y_exit("sigaction", 1);
	
	char c;

	if (read(0, &c, sizeof(char)) < 0) {
		if (errno == EINTR) {
			write(1, "Read interrumpido por signal.\n", 30);
		}
		else {
			write(1, "Read ejecutado con error.\n", 26);
		}
	}
	else {
		write(1, "Read ejecutado correctamente.\n", 30);
		write(1, &c, sizeof(char));
	}

}
