#include <unistd.h>
#include <stdio.h>
#include <stdlib.h>
#include <signal.h>
#include <string.h>

int segundos = 0;

void error_y_exit(char *msg,int exit_status) {
    perror(msg);
    exit(exit_status);
}

void trata_alarma(int s) {
	if (s == SIGALRM) {
		++segundos;
		alarm(1);
	}
	else if (s == SIGUSR1) segundos = 0;
	else if (s == SIGUSR2) {
		char buff[50];
		sprintf(buff,"%d segundos\n",segundos);
	    write(1, buff, strlen(buff)); 
	}
}

int main() {
	sigset_t mask;
	
	sigemptyset(&mask);
	sigaddset(&mask,SIGALRM);
	sigaddset(&mask,SIGUSR1);
	sigaddset(&mask,SIGUSR2);
	sigprocmask(SIG_BLOCK,&mask, NULL);
	
	struct sigaction sa;
	sa.sa_handler = &trata_alarma;
	sa.sa_flags = SA_RESTART;
	sigfillset(&sa.sa_mask);
	if (sigaction(SIGALRM, &sa, NULL) < 0) error_y_exit("sigaction", 1);
	if (sigaction(SIGUSR1, &sa, NULL) < 0) error_y_exit("sigaction", 1);
	if (sigaction(SIGUSR2, &sa, NULL) < 0) error_y_exit("sigaction", 1);
	
	sigemptyset(&mask);
	sigprocmask(SIG_SETMASK,&mask, NULL);
	
	alarm(1);
	
	while (1);
}
