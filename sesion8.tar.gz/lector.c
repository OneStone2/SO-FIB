#include <stdlib.h>
#include <string.h>
#include <stdio.h>
#include <unistd.h>
#include <errno.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>

void error_y_exit(char* msg,int exitStatus) {
	perror(msg);
	exit(exitStatus);
}


int main() {
	char buf[256];
	if (mknod("lol", S_IFIFO|0664, 0) < 0) {
		if (errno != EEXIST) error_y_exit("pipe", 1);
	}
	int x = open("lol", O_RDONLY), y;
	while ((y = read(x, buf, sizeof(buf))) > 0) {
		write(1, buf, y);
	}
	close(x);
}
