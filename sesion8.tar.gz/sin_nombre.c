#include <stdlib.h>
#include <string.h>
#include <stdio.h>
#include <unistd.h>

void error_y_exit(char* msg,int exitStatus) {
	perror(msg);
	exit(exitStatus);
}


int main() {
	char buf[256];
	int fd[2];
	if (pipe(fd) < 0) error_y_exit("pipe", 1);
	int pid = fork();
	if (pid == 0) {
		close(0);
		dup(fd[0]);
		close(fd[0]);
		close(fd[1]);
		execlp("cat", "cat", (char*)NULL);
		error_y_exit("execlp", 1); 
	}
	else {
		close(fd[0]);
		write(fd[1], "Inicio\n", 7);
		close(fd[1]);	
		waitpid(-1, NULL, 0);
		write(1, "Fin\n", 4);
	}
}
