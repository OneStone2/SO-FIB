#include <stdlib.h>
#include <string.h>
#include <stdio.h>
#include <unistd.h>
#include <errno.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <sys/socket.h>
#include <sys/un.h>
#include <fcntl.h>

void error_y_exit(char* msg,int exitStatus) {
	perror(msg);
	exit(exitStatus);
}


int main() {
	char buf[256];
	int socketFD = createSocket("foo");
    if (socketFD < 0) error_y_exit("socket", 1);
    int connectionFD = serverConnection(socketFD);
    if (connectionFD < 0) error_y_exit("socket", 1);
	int y;
	while ((y = read(connectionFD, buf, sizeof(buf))) > 0) {
		write(1, buf, y);
	}
	closeConnection(connectionFD);
    deleteSocket(socketFD, "foo");
}
