#include <stdlib.h>
#include <string.h>
#include <stdio.h>
#include <unistd.h>
#include <errno.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <sys/socket.h>
#include <sys/un.h>
#include <fcntl.h>

void error_y_exit(char* msg,int exitStatus) {
	perror(msg);
	exit(exitStatus);
}


int main() {
	char buf[256];
    int connectionFD = clientConnection("foo");
    if (connectionFD < 0) error_y_exit("socket", 1);
	int y;
	while ((y = read(0, buf, sizeof(buf))) > 0) {
		write(connectionFD, buf, y);
	}
	closeConnection(connectionFD);
}
